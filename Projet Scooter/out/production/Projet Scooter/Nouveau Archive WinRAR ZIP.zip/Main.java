import src.Graphique.FenetrePrincipale;
import src.Modele.*;

import javax.swing.*;
import java.util.*;

public class Main {
    public static void main(String[] args) {

        // 1. Création des scooters
        Scooter scooter1 = new Scooter("Yamaha", 1, 1000);
        Scooter scooter2 = new Scooter("Peugeot", 2, 2000);
        Scooter scooter3 = new Scooter("Honda", 3, 500);
        Scooter scooter4 = new Scooter("Ford", 4, 570);
        Scooter scooter5 = new Scooter("Kawasaki", 5, 1000);
        Scooter scooter6 = new Scooter("Kawasaki", 6, 1800);

        // 2. Création des types de scooters
        Type_Scooter typeElec = new Type_Scooter("électrique", 50, scooter1, null);
        Type_Scooter typeNonElec125 = new Type_Scooter("non électrique", 125, scooter2, null);
        Type_Scooter typeNonElec250 = new Type_Scooter("non électrique", 250, scooter3, null);

        // 3. Création des objets Permis
        Permis permisA = new Permis("A");
        Permis permisB = new Permis("B");
        Permis permisA1 = new Permis("A1");

        // 4. Association des permis requis aux types de scooter
        typeElec.setPermis(permisB); // Permis "A" pour le scooter électrique
        typeNonElec125.setPermis(permisA); // Permis "A" pour le scooter 125cc
        typeNonElec250.setPermis(permisA1); // Permis "B" pour le scooter 50cc

        // Association des types aux scooters
        scooter1.ajouterTypeScooter(typeElec);
        scooter2.ajouterTypeScooter(typeNonElec125);
        scooter3.ajouterTypeScooter(typeNonElec250);
        scooter4.ajouterTypeScooter(typeNonElec125);
        scooter5.ajouterTypeScooter(typeNonElec250);
        scooter6.ajouterTypeScooter(typeNonElec250);

        // 5. Création du magasin
        Magasin_Scooter magasin = new Magasin_Scooter("ScootShop", "123 Rue du Scooter");

        // Ajout des scooters à la liste
        magasin.ajouterScooter(scooter1);
        magasin.ajouterScooter(scooter2);
        magasin.ajouterScooter(scooter3);
        magasin.ajouterScooter(scooter4);
        magasin.ajouterScooter(scooter5);
        magasin.ajouterScooter(scooter6);

        // 6. Création d’un client
        Client client1 = new Client("Dupont", "Jean", 1, "0601020304");
        Client client2 = new Client("Medja", "Kayne", 2, "0787859324");
        Client client3 = new Client("Moha", "Koumo", 1, "0611223344");
        Client client4 = new Client("Doums", "Dylan", 1, "0721324354");

        // 7. Dates pour la location
        Calendar cal = Calendar.getInstance();
        Date dateDebut = cal.getTime();

        cal.add(Calendar.DAY_OF_MONTH, 3);
        Date dateFin = cal.getTime();

        // Dates pour la 2e location (avant-hier -> hier)
        Calendar cal2 = Calendar.getInstance();
        cal2.add(Calendar.DAY_OF_MONTH, -2);
        Date dateDebut2 = cal2.getTime(); // avant-hier

        cal2.add(Calendar.DAY_OF_MONTH, 1);
        Date dateFin2 = cal2.getTime(); // hier

        Calendar cal3 = Calendar.getInstance();
        cal3.add(Calendar.DAY_OF_MONTH, -1);
        Date dateDebut3 = cal3.getTime(); // hier
        cal3.add(Calendar.DAY_OF_MONTH, 2);
        Date dateFin3 = cal3.getTime(); // demain

        Date dateRetour3 = new Date(); // aujourd'hui

        // 8. Création de la location et réservation du scooter1
        Location location1 = new Location(Location.generateIdLocation(), dateDebut, dateFin, 0.0);
        location1.reserver(client1, scooter1, dateDebut, dateFin);

        Location location2 = new Location(Location.generateIdLocation(), dateDebut2, dateFin2, 0.0);
        location2.reserver(client2, scooter2, dateDebut2, dateFin2);

        Location location3 = new Location(Location.generateIdLocation(), dateDebut, dateFin, 0.0);
        location3.reserver(client3, scooter3, dateDebut, dateFin);

        Retour retour1 = new Retour("bon", 0.0, 0, dateFin2, location1);
        retour1.setfrais_retour(retour1.calculerFraisSup(dateDebut, dateFin2, "bon"));

        Retour retour2 = new Retour("peu endommagé", 0.0, 0, dateRetour3, location2);
        retour2.setfrais_retour(retour2.calculerFraisSup(dateDebut3, dateFin3, "peu endommagé"));
        retour2.mettreAJourDateFinLocation(location3);
        

        // Lancer la fenêtre principale de l'application
        SwingUtilities.invokeLater(() -> {
            new FenetrePrincipale(magasin); // Lancement de la fenêtre principale
        });
    }
}
