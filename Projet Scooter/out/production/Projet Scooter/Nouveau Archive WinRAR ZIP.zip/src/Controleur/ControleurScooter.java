package src.Controleur;

import src.Modele.*;

import javax.swing.*;
import java.util.List;

public class ControleurScooter {

    private Magasin_Scooter magasin;
    private JTextArea affichage;

    public ControleurScooter(Magasin_Scooter magasin, JTextArea affichage) {
        this.magasin = magasin;
        this.affichage = affichage;
    }

    public void supprimerScooterDepuisDialogue(JFrame parent) {
        String idASupprimer = JOptionPane.showInputDialog(parent, "Entrez l'ID du scooter à supprimer :");
        if (idASupprimer == null || idASupprimer.trim().isEmpty())
            return;

        boolean supprimé = false;
        List<Scooter> scooters = magasin.getscooter(); // on bosse sur la vraie liste

        for (int i = 0; i < scooters.size(); i++) {
            if (String.valueOf(scooters.get(i).getId()).equalsIgnoreCase(idASupprimer.trim())) {
                scooters.remove(i);
                supprimé = true;
                break;
            }
        }

        if (supprimé) {
            affichage.append("Scooter ID " + idASupprimer + " supprimé.\n");
        } else {
            JOptionPane.showMessageDialog(parent, "Scooter non trouvé !");
        }
    }

}