package src.Controleur;

import javax.swing.*;

public class ControleurRetours {

    public static void effectuerRetour(JFrame parent) {
        // Logique pour effectuer un retour (à adapter)
        JOptionPane.showMessageDialog(parent, "Retour effectué avec succès !");
    }
}