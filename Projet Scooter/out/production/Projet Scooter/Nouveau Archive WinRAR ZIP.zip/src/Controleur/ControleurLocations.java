package src.Controleur;

import javax.swing.*;

public class ControleurLocations {

    public static void louerScooter(JFrame parent) {
        JOptionPane.showMessageDialog(parent, "Louer un scooter : à implémenter.");
    }

    public static void supprimerLocation(JFrame parent) {
        JOptionPane.showMessageDialog(parent, "Suppression d'une location : à implémenter.");
    }
}
