package src.Controleur;

import javax.swing.*;

public class ControleurClients {

    public static void seConnecter(JFrame parent) {
        JOptionPane.showMessageDialog(parent, "Connexion client non encore implémentée.");
    }

    public static void ajouterClient(JFrame parent) {
        JOptionPane.showMessageDialog(parent, "Ajout de client non encore implémenté.");
    }

    public static void modifierClient(JFrame parent) {
        JOptionPane.showMessageDialog(parent, "Modification de client non encore implémentée.");
    }
}
