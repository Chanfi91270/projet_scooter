package src.Graphique;

import javax.swing.*;
import java.awt.*;
import src.Controleur.ControleurLocations;

public class FenetreLocations extends JFrame {

    public FenetreLocations(FenetrePrincipale fenetrePrincipale) {
        setTitle("Gestion des Locations");
        setSize(550, 220);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JLabel titre = new JLabel("Gestion des Locations", SwingConstants.CENTER);
        titre.setFont(new Font("Arial", Font.BOLD, 18));
        titre.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panel.add(titre, BorderLayout.NORTH);

        JPanel centre = new JPanel();
        centre.setLayout(new BoxLayout(centre, BoxLayout.Y_AXIS));
        centre.setBorder(BorderFactory.createEmptyBorder(0, 50, 0, 50));

        JLabel label = new JLabel("Que voulez-vous faire ?", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.PLAIN, 14));
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        label.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        centre.add(label);

        JPanel boutons = new JPanel(new GridLayout(1, 2, 25, 0));

        JButton boutonLouer = new JButton("Louer un scooter");
        boutonLouer.setFont(new Font("Tahoma", Font.PLAIN, 14));
        boutonLouer.setFocusPainted(false);
        boutonLouer.setMaximumSize(new Dimension(200, 40));
        boutonLouer.setPreferredSize(new Dimension(200, 40));
        boutonLouer.addActionListener(e -> ControleurLocations.louerScooter(this));
        boutons.add(boutonLouer);

        JButton boutonSupprimer = new JButton("Supprimer une location");
        boutonSupprimer.setFont(new Font("Tahoma", Font.PLAIN, 14));
        boutonSupprimer.setFocusPainted(false);
        boutonSupprimer.setMaximumSize(new Dimension(200, 40));
        boutonSupprimer.setPreferredSize(new Dimension(200, 40));
        boutonSupprimer.addActionListener(e -> ControleurLocations.supprimerLocation(this));
        boutons.add(boutonSupprimer);

        centre.add(boutons);
        panel.add(centre, BorderLayout.CENTER);

        JButton boutonAccueil = new JButton("Accueil");
        boutonAccueil.setFont(new Font("Tahoma", Font.PLAIN, 14));
        boutonAccueil.setFocusPainted(false);
        boutonAccueil.addActionListener(e -> {
            fenetrePrincipale.setVisible(true);
            this.dispose();
        });

        JPanel panelAccueil = new JPanel();
        panelAccueil.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        panelAccueil.add(boutonAccueil);

        panel.add(panelAccueil, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);
    }
}
