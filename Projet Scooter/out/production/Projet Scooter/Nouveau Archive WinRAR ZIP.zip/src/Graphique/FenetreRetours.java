package src.Graphique;

import javax.swing.*;
import java.awt.*;

import src.Controleur.ControleurRetours;


public class FenetreRetours extends JFrame {
    public FenetreRetours(FenetrePrincipale fenetrePrincipale) {
        setTitle("Gestion des Retours");
        setSize(350, 200);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout());

        JLabel label = new JLabel("📦 Gestion Retours", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setBorder(BorderFactory.createEmptyBorder(20, 0, 10, 0));
        panel.add(label, BorderLayout.NORTH);

        // Bouton Effectuer un retour
        JButton boutonRetour = new JButton("Effectuer un retour");
        boutonRetour.setFont(new Font("Tahoma", Font.PLAIN, 14));
        boutonRetour.setFocusPainted(false);
        boutonRetour.setPreferredSize(new Dimension(200, 35));

        // ActionListener pour retour
        boutonRetour.addActionListener(e -> {
            ControleurRetours.effectuerRetour(this); // Appel au contrôleur
        });

        JPanel centrePanel = new JPanel();
        centrePanel.add(boutonRetour);
        panel.add(centrePanel, BorderLayout.CENTER);

        // Bouton Accueil
        JButton boutonAccueil = new JButton("🏠 Accueil");
        boutonAccueil.setFont(new Font("Tahoma", Font.PLAIN, 13));
        boutonAccueil.setFocusPainted(false);
        boutonAccueil.setPreferredSize(new Dimension(120, 30));

        boutonAccueil.addActionListener(e -> {
            fenetrePrincipale.setVisible(true);
            this.dispose();
        });

        JPanel basPanel = new JPanel();
        basPanel.setBorder(BorderFactory.createEmptyBorder(5, 0, 10, 0));
        basPanel.add(boutonAccueil);
        panel.add(basPanel, BorderLayout.SOUTH);

        add(panel);
        setVisible(true);
    }
}
