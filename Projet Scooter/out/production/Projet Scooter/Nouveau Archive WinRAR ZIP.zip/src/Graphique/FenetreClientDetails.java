package src.Graphique;

import src.Modele.*;
import src.Graphique.*;
import javax.swing.*;
import java.awt.*;

public class FenetreClientDetails extends JFrame {
    private FenetreClients fenetreClients;

    public FenetreClientDetails(FenetreClients fenetreClients) {
        this.fenetreClients = fenetreClients;

        setTitle("Détails du Client");
        setSize(500, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        JPanel panel = new JPanel(new BorderLayout(10, 10));

        JLabel label = new JLabel("Infos client & Locations en cours", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 18));
        panel.add(label, BorderLayout.NORTH);

        JTextArea textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setText("Affichage des informations du client et de ses locations en cours...\n\n(à implémenter plus tard)");
        panel.add(new JScrollPane(textArea), BorderLayout.CENTER);

        JButton btnRetour = new JButton("Retour");
        btnRetour.addActionListener(e -> {
            this.dispose();
            fenetreClients.setVisible(true);
        });
        panel.add(btnRetour, BorderLayout.SOUTH);

        add(panel);
    }
}
