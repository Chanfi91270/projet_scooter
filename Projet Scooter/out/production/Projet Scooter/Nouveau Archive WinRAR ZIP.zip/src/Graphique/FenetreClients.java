package src.Graphique;

import javax.swing.*;
import java.awt.*;
import javax.swing.border.TitledBorder;
import src.Controleur.ControleurClients;

public class FenetreClients extends JFrame {

    public FenetreClients(FenetrePrincipale fenetrePrincipale) {
        setTitle("Gestion des Clients");
        setSize(400, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);

        Color fond = new Color(245, 245, 245);
        Color bleu = new Color(59, 89, 182);

        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(fond);

        JLabel header = new JLabel("Gestion des Clients", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 24));
        header.setBorder(BorderFactory.createEmptyBorder(20, 0, 20, 0));
        panel.add(header, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.Y_AXIS));
        buttonPanel.setBackground(fond);
        buttonPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(bleu, 2),
                "Actions Clients",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Tahoma", Font.BOLD, 16),
                bleu
        ));

        // Bouton Se connecter
        JButton boutonSeConnecter = new JButton("Se connecter");
        boutonSeConnecter.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        boutonSeConnecter.setFocusPainted(false);
        boutonSeConnecter.setAlignmentX(Component.CENTER_ALIGNMENT);
        boutonSeConnecter.setMaximumSize(new Dimension(240, 40));
        boutonSeConnecter.addActionListener(e -> ControleurClients.seConnecter(this));

        // Bouton Ajouter un client
        JButton boutonAjouter = new JButton("Ajouter un client");
        boutonAjouter.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        boutonAjouter.setFocusPainted(false);
        boutonAjouter.setAlignmentX(Component.CENTER_ALIGNMENT);
        boutonAjouter.setMaximumSize(new Dimension(240, 40));
        boutonAjouter.addActionListener(e -> ControleurClients.ajouterClient(this));

        // Bouton Modifier informations client
        JButton boutonModifier = new JButton("Modifier informations client");
        boutonModifier.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        boutonModifier.setFocusPainted(false);
        boutonModifier.setAlignmentX(Component.CENTER_ALIGNMENT);
        boutonModifier.setMaximumSize(new Dimension(240, 40));
        boutonModifier.addActionListener(e -> ControleurClients.modifierClient(this));

        buttonPanel.add(boutonSeConnecter);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        buttonPanel.add(boutonAjouter);
        buttonPanel.add(Box.createRigidArea(new Dimension(0, 15)));
        buttonPanel.add(boutonModifier);

        panel.add(buttonPanel, BorderLayout.CENTER);

        // Bouton Accueil
        JButton boutonAccueil = new JButton("🏠 Accueil");
        boutonAccueil.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        boutonAccueil.setFocusPainted(false);
        boutonAccueil.setMaximumSize(new Dimension(240, 40));
        boutonAccueil.addActionListener(e -> {
            fenetrePrincipale.setVisible(true);
            this.dispose();
        });

        JPanel panelAccueil = new JPanel();
        panelAccueil.setBackground(fond);
        panelAccueil.setBorder(BorderFactory.createEmptyBorder(10, 10, 20, 10));
        panelAccueil.add(boutonAccueil);

        panel.add(panelAccueil, BorderLayout.SOUTH);
        add(panel);
    }
}
